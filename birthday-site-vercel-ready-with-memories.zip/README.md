# Ten Years of Us

A three-page birthday surprise for a best friend of ten years.

## Run locally

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Publish with GitHub and Vercel

1. Create a new empty repository on GitHub.
2. Upload every file and folder from this project to the repository root.
3. In Vercel, choose **Add New → Project** and import the repository.
4. Keep the detected **Next.js** settings and click **Deploy**.

No environment variables are required.

## Personalize

Edit the birthday message in `app/page.tsx`. The seven supplied photos and two videos are already included in `public/memories` and `public/videos`. Extra photos or a replacement video can still be selected in the published website; those optional selections remain on the visitor's device for the current session.
