import type { Metadata } from "next";
import "./globals.css";
import "./media.css";
export const metadata: Metadata={title:"10 Years of Us",description:"A birthday surprise for my best friend of ten years."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
