"use client";
import Link from "next/link";
import { useState } from "react";
type Memory = { url: string; caption: string };
const ourMemories: Memory[] = [
  { url: "/memories/01-school-days.jpg", caption: "Where our ten-year story quietly began." },
  { url: "/memories/02-holi-smiles.jpg", caption: "Holi was brighter because we celebrated it together." },
  { url: "/memories/03-grown-together.jpg", caption: "Different years, same smiles, same safe place." },
  { url: "/memories/04-colour-chaos.jpg", caption: "Our favourite kind of beautiful chaos." },
  { url: "/memories/05-birthday-glow.jpg", caption: "Another birthday, another memory I get to keep." },
  { url: "/memories/06-adventure-day.jpg", caption: "Every ordinary outing becomes a story with you." },
  { url: "/memories/07-mirror-mischief.jpg", caption: "Proof that we can never take a normal picture." },
];
export default function Memories() {
  const [items, setItems] = useState<Memory[]>(ourMemories);
  const [caption, setCaption] = useState("");
  const addMemory = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setItems((current) => [...current, { url: URL.createObjectURL(file), caption: caption || "A moment I never want to forget." }]);
    setCaption("");
  };
  return <main className="memory-page">
    <nav className="nav"><Link href="/">← THE LETTER</Link><span>CHAPTER 02 / OUR ARCHIVE</span></nav>
    <header className="memory-head"><p className="eyebrow">Proof that we actually grew up together</p><h1>OUR<br /><i>MEMORY</i> WALL</h1></header>
    <section className="uploader"><div><b>ADD ONE MORE</b><p>Choose a photo and give it one tiny sentence.</p></div><input value={caption} onChange={(event) => setCaption(event.target.value)} placeholder="That day we laughed until it hurt…" aria-label="Photo caption" /><label className="upload-btn">CHOOSE PHOTO +<input type="file" accept="image/*" onChange={addMemory} /></label></section>
    <section className="photo-grid" aria-label="Our friendship memories">{items.map((memory, index) => <figure key={`${memory.url}-${index}`} style={{ transform: `rotate(${index % 2 ? 1.4 : -1.4}deg)` }}><img src={memory.url} alt={memory.caption} /><figcaption><b>{String(index + 1).padStart(2, "0")}</b>{memory.caption}</figcaption></figure>)}</section>
    <div className="next-wrap"><Link className="start" href="/cinema"><span>PLAY OUR<br />LITTLE MOVIE</span><b>→</b></Link></div>
  </main>;
}
