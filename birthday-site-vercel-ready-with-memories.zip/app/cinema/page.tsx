"use client";
import Link from "next/link";
import { useRef, useState } from "react";
const films = ["/videos/memory-film-1.mp4", "/videos/memory-film-2.mp4"];
export default function Cinema() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [filmIndex, setFilmIndex] = useState(0);
  const [customFilm, setCustomFilm] = useState("");
  const [muted, setMuted] = useState(true);
  const source = customFilm || films[filmIndex];
  const toggleSound = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !muted;
    setMuted(!muted);
    void videoRef.current.play();
  };
  return <main className="cinema">
    <video ref={videoRef} key={source} autoPlay muted={muted} playsInline poster="/memories/05-birthday-glow.jpg" src={source} onEnded={() => customFilm ? videoRef.current?.play() : setFilmIndex((filmIndex + 1) % films.length)} />
    <div className="cinema-shade" />
    <nav className="nav cinema-nav"><Link href="/memories">← MEMORIES</Link><span>CHAPTER 03 / PRESS PLAY</span></nav>
    <section className="finale"><p className="eyebrow">Ten years down. A lifetime to go.</p><h1>TO ALL THE<br />MEMORIES<br /><i>YET TO COME.</i></h1><p>Happy birthday to my safest place, loudest laugh, and forever favourite person.</p><div className="film-controls"><button type="button" className="sound-button" onClick={toggleSound}>{muted ? "HEAR OUR MEMORY" : "MUTE VIDEO"} ♪</button><label className="video-upload">CHANGE VIDEO ↗<input type="file" accept="video/*" onChange={(event) => { const file = event.target.files?.[0]; if (file) setCustomFilm(URL.createObjectURL(file)); }} /></label></div></section>
    <div className="rec">● REC &nbsp; 10:00 YEARS &nbsp; {customFilm ? "YOUR CUT" : `FILM 0${filmIndex + 1}/02`}</div>
  </main>;
}
